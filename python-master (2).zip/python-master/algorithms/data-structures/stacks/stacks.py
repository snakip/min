myStack = []

myStack.append('a')
myStack.append('b')
myStack.append('c')

myStack


myStack.pop()

myStack.pop()

myStack.pop()


myStack.pop()